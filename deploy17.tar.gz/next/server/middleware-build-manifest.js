globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/2e1f37b1c3eb9b3f.js",
    "static/chunks/158679df3034e338.js",
    "static/chunks/154162a07641e3f8.js",
    "static/chunks/9f613523b8224e65.js",
    "static/chunks/turbopack-ce547c5c3b3b0d67.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];