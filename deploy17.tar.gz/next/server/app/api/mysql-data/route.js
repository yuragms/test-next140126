var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/mysql-data/route.js")
R.c("server/chunks/[externals]__625f014f._.js")
R.c("server/chunks/[root-of-the-server]__91939293._.js")
R.c("server/chunks/[root-of-the-server]__4a222162._.js")
R.c("server/chunks/_next-internal_server_app_api_mysql-data_route_actions_7b10d441.js")
R.m(90518)
module.exports=R.m(90518).exports
