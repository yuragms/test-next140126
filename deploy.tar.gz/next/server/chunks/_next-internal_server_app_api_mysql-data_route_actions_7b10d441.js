module.exports=[90185,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_mysql-data_route_actions_7b10d441.js.map